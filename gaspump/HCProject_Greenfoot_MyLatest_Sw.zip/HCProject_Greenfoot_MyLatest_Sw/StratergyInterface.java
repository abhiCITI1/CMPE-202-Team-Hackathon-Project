/**
 * Write a description of class StratergyInterface here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface StratergyInterface  
{
    public boolean hasCollisionOccured(Class CollidingClass);
    public boolean hasRightCard();
    public void act();

    
}
